//6DOF V4
//New layout, RN Bluetooth, z mag sensor


/* *********************************************************
               Function declarations
  ********************************************************* */

#define IAP_LOCATION  0x7FFFFFF1

void Initialize(void);
void feed(void);

void setup_uart0(int baud);
void setup_uart1(int baud, char want_ints);


void get_adc(void);
void save_settings(void);
void set_flags(void);


char getc(void);

void stat0_on (void);
void stat0_off (void);

void stat1_on (void);
void stat1_off (void);

void stat2_on (void);
void stat2_off (void);

void config_menu(void);
void put_char(char c);
char getc2(void);



/**********************************************************
                  Header files
 **********************************************************/
#include "LPC21xx_SFE.h"
#include "rprintf.h"


/**********************************************************
                  Global Variables
 **********************************************************/
 
char port = 1;        //determines which port will be written to
char RX_array[512];
char temp_array[5];
char asc;
char BT_active;
char check_BT;

short RX_in = 0, RX_out = 0;
int pitch, roll, yaw, accx, accy, accz, magx, magy, magz;
char pitch_on = 0, roll_on = 0, yaw_on = 0;
char accx_on = 0, accy_on = 0, accz_on = 0;
char magx_on = 0, magy_on = 0, magz_on = 0;
int freq = 0;
char auto_run = 0, range = 0;


#define RAMSPOT        (*((volatile unsigned long *) 0x40007E80))

#define FLASHSPOT        (*((volatile unsigned long *) 0x0007C000))


unsigned long command[5];
unsigned long result[2];

typedef void (*IAP)(unsigned long[],unsigned long[]);

IAP iap_entry;



/**********************************************************
                       MAIN
**********************************************************/


int	main (void)
{	
	int	k, j;

    //int i, j;
	char q;
    char temp;
	
	Initialize();
	
	rprintf_devopen(put_char); /* init rrprintf */
	
	setup_uart0(115200);
	rprintf("UART0 setup...\r\n",0);

    setup_uart1(115200,0);
	
	U0FCR = 0x02;     //Clear the RX fifo on the hard line

	for (k = 0; k < 1000000; k++);
	
	check_BT = 0;
	port = 0;

	for (j = 0; j < 5; j++)
	{
		stat0_on();
		for (k = 0; k < 75000; k++);
		stat0_off();
		stat1_on();
		for (k = 0; k < 75000; k++);
		stat1_off();
		stat2_on();
		for (k = 0; k < 75000; k++);
		stat2_off();
	}
        
	
	RAMSPOT = FLASHSPOT;  //get settings

	if ((RAMSPOT & 0xFF000000) == 0xFF000000)   //if it hasn't been written to yet
	{
		RAMSPOT = 0x018640FF;   //all channels active, binary mode, auto run off, 1.5g, 100Hz, BT active

		save_settings();
		
	}

	set_flags();
	
	if ((U0LSR & 0x01) != 0)
	{
		q = U0RBR;
		if (q == 32) config_menu();
		rprintf("\r\nPlease reset your 6DOF for the settings to take effect.\r\n",0);
		while(1);
	}
		
		


	port = BT_active;
	check_BT = BT_active;
	
	

	if (BT_active == 1) while((IOPIN0 & 0x00040000) != 0x00040000);   //Wait for a Bluetooth connection
	
	

	while(1)
	{
		stat1_off();

		if (auto_run == 1)
		{
			while(1)
			{
				get_adc();

				U1FCR = 0x02;     //Clear the RX fifo if it dumps out
				U0FCR = 0x02;     //either port

				config_menu();

				if (auto_run == 0) break;
			}
		}

		if (port == 1) temp = U1LSR;
		else if (port == 0) temp = U0LSR;

		if ((temp & 0x01) != 0)	//if something comes in on port1...
		{
			  
		  if (port == 1) q = U1RBR;	//gotta read the RX buffer to set the flag back to 0
		  else if (port == 0) q = U0RBR;

		  if (q == 35)	//# to run
		  {
			  asc = 0;
			  get_adc();

			  if ((RAMSPOT & 0x100) == 0x100) asc = 1;

			  U1FCR = 0x02;     //Clear the RX fifo if it dumps out
			  U0FCR = 0x02;
		  }
		  
		  else if (q == 37)	//% to set range to 1.5g
		  {
 
			  //set for 1.5g sensitivity
			  IOCLR1 = 0x00010000;    //GS1 low
			  IOCLR0 = 0x80000000;    //GS2 low

		  }

		  else if (q == 38)	//& to set range to 2g
		  {
			  IOSET1 = 0x00010000;    //GS1 High
			  IOCLR0 = 0x80000000;    //GS2 low

			  
		  }

		  else if (q == 39)	//' to set range to 4g
		  {
			  IOCLR1 = 0x00010000;    //GS1 low
			  IOSET0 = 0x80000000;    //GS2 High
		  }

		  else if (q == 40)	//( to set range to 6g
		  {
			  IOSET1 = 0x00010000;    //GS1 High
			  IOSET0 = 0x80000000;    //GS2 High

		  }

		  else if (q == 41)	//) to run at 50Hz
		  {
			  T0MR0 = 1179648; //set timer for 50Hz
		  }

		  else if (q == 42)	// to run at 100Hz
		  {
			  T0MR0 = 589824; //set timer for 100Hz
		  }

		  else if (q == 43)	//+ to run at 150Hz
		  {
			  T0MR0 = 393216; //set timer for 150Hz
		  }

		  else if (q == 44)	//, to run at 200Hz
		  {
			  T0MR0 = 294912; //set timer for 200Hz
		  }

		  else if (q == 45)	//- to run at 250Hz
		  {
			  T0MR0 = 235930; //set timer for 250Hz
		  }

		  else if (q == 46)	//. to run at 300Hz
		  {
			  T0MR0 = 196608; //set timer for 300Hz
		  }

		  else if (q == 32)	//
		  {
			  while(1)
			  {
				  config_menu();

				  if (auto_run == 0) break;

				  get_adc();

				  U1FCR = 0x02;     //Clear the RX fifo if it dumps out
				  U0FCR = 0x02;
			  }
		  }

		  q = 0;

			  
		}
	}
	
	
	while(1);

		
}



/**********************************************************
                      Initialize
**********************************************************/

#define PLOCK 0x400

void Initialize(void)
{
    // Setting Multiplier and Divider values
  	PLLCFG=0x23;
  	feed();
  
	// Enabling the PLL */	
	PLLCON=0x1;
	feed();
  
	// Wait for the PLL to lock to set frequency
	while(!(PLLSTAT & PLOCK)) ;
  
	// Connect the PLL as the clock source
	PLLCON=0x3;
	feed();
  
	// Enabling MAM and setting number of clocks used for Flash memory fetch (4 cclks in this case)
	MAMCR=0x2;
	MAMTIM=0x4;
  
	// Setting peripheral Clock (pclk) to System Clock (cclk)
	VPBDIV=0x01;
	
	/*
	MagX = AD0.4
	MagY = AD0.5
	MagZ = AD0.0
	AccX = AD0.1
	AccY = AD0.2
	AccZ = AD0.3
	Pitch = AD1.3
	Roll = AD1.4
	Yaw = AD1.5
	*/
	
    PINSEL0 = 0xCF050005;   // enable uart0, enable uart1, AD1.3, 4 and 5 enabled
	
	PINSEL1 = 0x15540000;	//AD0.0 through AD0.5 (not AD0.2), AD1.7 enabled
							
	IODIR0 = 0x80600000;    //P0.31 = GS2, P0.22 = Stat1, P0.21 = stat0
	IODIR1 = 0x000B0000;	//P1.19 = Stat2, P1.17 = set/reset, P1.16 = GS1

	
	IOSET0 = 0x00600000;	// Stat0 & Stat1 high
	IOSET1 = 0x000A0000;	//Stat2 high, set/reset high
	IOCLR0 = 0x80000000;    //GS2 low
	IOCLR1 = 0x00010000;    //GS1 low
        

        
	T0MR0 = 294912;   //200Hz default
	
	T0MCR = 0x0003;
	T0TCR = 1;

	
}


void feed(void)
{
  PLLFEED=0xAA;
  PLLFEED=0x55;
}





void put_char(char c)
{
    if (check_BT == 1) while((IOPIN0 & 0x00040000) != 0x00040000);  //Make sure we've got a BT connection, changed for new BT, 15/15/07

    if (port == 0)
    {
        while((U0LSR & 0x20) == 0);
        U0THR = c;
    }
    else if (port == 1)
    {
        while((U1LSR & 0x20) == 0);
        U1THR = c;
    }
}


//specific to UART0
char getc(void)
{
    while((U0LSR & 0x01) == 0);
    return (U0RBR);
}


char getc2(void)
{
    while((U1LSR & 0x01) == 0);
    return (U1RBR);
}


void stat0_on (void)
{
	IOCLR0 = 0x00200000;

}

void stat0_off (void)
{
	IOSET0 = 0x00200000;
	
}

void stat1_on (void)
{
	IOCLR0 = 0x00400000;

}

void stat1_off (void)
{
	IOSET0 = 0x00400000;
	
}

void stat2_on (void)
{
	IOCLR1 = 0x00080000;

}

void stat2_off (void)
{
	IOSET1 = 0x00080000;
	
}



void setup_uart0(int baud)
{
	
	//set up uart0 
	U0LCR = 0x83;			// 8 bits, no Parity, 1 Stop bit, DLAB = 1
	
	
	if (baud == 1200)
	{
		U0DLM   = 0x0C;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 2400)
	{
		U0DLM   = 0x06;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
		
	if (baud == 4800)
	{
		U0DLM   = 0x03;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 9600)
	{
	 	U0DLM   = 0x01;		  	//
  		U0DLL 	= 0x80;        	// 9600 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 19200)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0xC0;        	// 19200 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 38400)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x60;        	// 38400 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 57600)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x40;        	// 57600 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 115200)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x20;        	// 115200 Baud Rate @ 58982400 VPB Clock
	}
	                    
  	U0FCR	= 0x01;			// Not sure this is necessary, but the manual sez it is
	U0LCR 	= 0x03;        	// DLAB = 0
	
	//set up UART0 interupt
  	//VICIntSelect = 0x00000040;	//bit 6 is for UART0, sets to FIQ (not IRQ)
  	//VICIntEnable = 0x00000040;	//enables UART0 interupt
  	//VICVectCntl0 = 0x00000026;	//Set UART0 to slot 0 in the IRQ's
 	//U0IER = 0x01;				//enable RX data available interupt, DLAB must be 0 to write
	
}


void setup_uart1(int baud, char want_ints)
{
	//set up uart1
	U1LCR 	= 0x83;			// 8 bits, no Parity, 1 Stop bit, DLAB = 1
	
	if (baud == 1200)
	{
		U1DLM   = 0x0C;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 2400)
	{
		U1DLM   = 0x06;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 4800)
	{
		U1DLM   = 0x03;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 9600)
	{
	 	U1DLM   = 0x01;		  	//
  		U1DLL 	= 0x80;        	// 9600 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 19200)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0xC0;        	// 19200 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 38400)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0x60;        	// 38400 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 57600)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0x40;        	// 57600 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 115200)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0x20;        	// 115200 Baud Rate @ 58982400 VPB Clock
	}
	//U1IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write               
  	U1FCR	= 0x01;			// Not sure this is necessary, but the manual sez it is
  	
	U1LCR 	= 0x03;        	// DLAB = 0
	
	
	if (want_ints == 1)
	{
			/*
            stat1_on();
            // UART1 interrupt is an IRQ interrupt 
            VICIntSelect &= ~0x80;
            // Enable UART interrupt 
            VICIntEnable = 0x80;
            // Use slot 0 for UART1 interrupt 
            VICVectCntl0 = 0x27;
            // Set the address of ISR for slot 0 
            VICVectAddr0 = (unsigned int)UART1ISR;

            __ARMLIB_enableIRQ();

            //VICIntSelect |= 0x00000080;		//bit 7 is for UART1, sets to FIQ (not IRQ)
            //VICIntEnable |= 0x00000080;	//enables UART1 interupt
            U1IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write
			*/
		
	}
	
	else if (want_ints == 0)
	{
		VICIntEnClr = 0x00000080;	//disables UART1 interupt
		U1IER = 0x00;					//disable RX data available interupt, DLAB must be 0 to write
	}
	

}



void config_menu(void)
{
	char a;
	
	stat0_on();
	stat1_on();
	stat2_on();
        //port = 1;

	while (1)
	{
		rprintf("\r\n6DOF V4 setup, version 1.0\r\n",0);
		rprintf("========================================\r\n",0);
		
		rprintf("1) View/edit active channel list\r\n",0);
                rprintf("2) Change output mode, curerntly ",0);
                if (asc == 0) rprintf("binary\r\n",0);
                else rprintf("ASCII\r\n",0);
                rprintf("3) Set Auto run mode, curerntly ",0);
                if (auto_run == 0) rprintf("off\r\n",0);
                else rprintf("on\r\n",0);
                rprintf("4) Set accelerometer sensitivity, currently ",0);
                if ((RAMSPOT & 0x00000C00) == 0) rprintf("1.5g\r\n",0);
                else if ((RAMSPOT & 0x00000C00) == 0x400) rprintf("2g\r\n",0);
                else if ((RAMSPOT & 0x00000C00) == 0x800) rprintf("4g\r\n",0);
                else if ((RAMSPOT & 0x00000C00) == 0xC00) rprintf("6g\r\n",0);
                rprintf("5) Set output frequency, currently %d\r\n",freq);
                rprintf("6) Change output port, currently ",0);
                if ((RAMSPOT & 0x00800000) == 0x800000) rprintf("Bluetooth\r\n",0);
                else rprintf("Serial TTL\r\n",0);
                
		rprintf("9) Save settings and run unit\r\n",0);
		

		U1FCR = 0x02;   //Clear the RX fifo
                U0FCR = 0x02;
		if (port == 1) a = getc2();
                else a = getc();
		
                
                if (a == '1')
                {
                    while(1)
                    {
                        rprintf("\r\n\n1) Magneto X = ",0);
                        if (magx_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("2) Magneto Y = ",0);
                        if (magy_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);
						
						rprintf("3) Magneto Z = ",0);
                        if (magz_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("4) Accel X = ",0);
                        if (accx_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("5) Accel Y = ",0);
                        if (accy_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("6) Accel Z = ",0);
                        if (accz_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("7) Pitch = ",0);
                        if (pitch_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("8) Roll = ",0);
                        if (roll_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("9) Yaw = ",0);
                        if (yaw_on == 1) rprintf("on\r\n",0);
                        else rprintf("off\r\n",0);

                        rprintf("Press the number of the channel you wish to change,\r\n",0);
                        rprintf("or press x to exit\r\n",0);

                        if (port == 1) a = getc2();
                        else a = getc();

                        if (a == '1')
                        {
                            magx_on ^= 0x01;
                            RAMSPOT ^= 0x01;
                        }

                        else if (a == '2')
                        {
                            magy_on ^= 0x01;
                            RAMSPOT ^= 0x02;
                        }
						
						else if (a == '3')
                        {
                            magz_on ^= 0x01;
                            RAMSPOT ^= 0x01000000;
                        }

                        else if (a == '4')
                        {
                            accx_on ^= 0x01;
                            RAMSPOT ^= 0x04;
                        }

                        else if (a == '5')
                        {
                            accy_on ^= 0x01;
                            RAMSPOT ^= 0x08;
                        }

                        else if (a == '6')
                        {
                            accz_on ^= 0x01;
                            RAMSPOT ^= 0x10;
                        }

                        else if (a == '7')
                        {
                            pitch_on ^= 0x01;
                            RAMSPOT ^= 0x20;
                        }

                        else if (a == '8')
                        {
                            roll_on ^= 0x01;
                            RAMSPOT ^= 0x40;
                        }

                        else if (a == '9')
                        {
                            yaw_on ^= 0x01;
                            RAMSPOT ^= 0x80;
                        }

                        else if (a == 'x')
                        {
                            a = 0;
                            break;
                        }

                    }

                }

                
                else if (a == '2')
                {
                    asc ^= 1;
                    RAMSPOT ^= 0x100;
                }

                else if (a == '3')
                {
                    auto_run ^= 1;
                    RAMSPOT ^= 0x200;
                }

                else if (a == '4')
                {
                    rprintf("\r\nSet to:\r\n",0);
                    rprintf("1) 1.5g\r\n",0);
                    rprintf("2) 2g\r\n",0);
                    rprintf("3) 4g\r\n",0);
                    rprintf("4) 6g\r\n",0);

                    
                    
                    while(1)
                    {
                        if (port == 1) a = getc2();
                        else a = getc();

                        if (a == '1')
                        {
                            RAMSPOT &= 0x01FFF3FF;
                            break;
                        }
                        else if (a == '2')
                        {
                            RAMSPOT &= 0x01FFF7FF;
                            RAMSPOT |= 0x400;
                            break;
                        }
                        else if (a == '3')
                        {
                            RAMSPOT &= 0x01FFFBFF;
                            RAMSPOT |= 0x800;
                            break;
                        }
                        else if (a == '4')
                        {
                            RAMSPOT |= 0xC00;
                            break;
                        }
                    }

                }

                else if(a == '5')
                {
                    rprintf("\r\nPress [i] to increase, [d] to decrease, [x] to exit\r\n",0);

                    while(1)
                    {
                        rprintf("%d",freq);

                        if (port == 1) a = getc2();
                        else a = getc();

                        if (a == 'i') freq++;
                        else if (a == 'd') freq--;
                        else if (a == 'x') break;

                        if (freq < 10) freq = 10;
                        rprintf("     \r",0);
                    }

                    RAMSPOT &= 0x01800FFF;  //zero out the frequency bits
                    RAMSPOT |= (freq*0x1000);

                }

                else if(a == '6')
                {
                    BT_active ^= 1;
                    RAMSPOT ^= 0x800000;
                    rprintf("Please exit the config menu and restart your 6DOF for this setting to take effect.\r\n",0);
                }

                
		else if (a == '9')
		{
                    stat0_off();
                    stat1_off();
					stat2_off();
                    save_settings();
                    set_flags();
                    rprintf("Exiting...\r\n",0);
                    break;
			
		}
                
				
		
	}
        
        
        
}


void get_adc(void)
{
    int temp = 0, j, k, time = 0;
    short a;
    char q, temp3;


    stat0_on();

    T0IR = 0x01;//reset timer int
    T0TCR = 3;  //reset timer
    T0TCR = 1;
    
    while(1)
    {
        
    
        pitch = 0, roll = 0, yaw = 0;
        accx = 0, accy = 0, accz = 0;
        magx = 0, magy = 0, magz = 0;
    
        put_char('A');  //start character

    
        //Send count first================================================================
        if (asc == 0)
        {
            a = ((short)time & 0x0000FF00) / 0x100;
            q = (char)a;
            put_char(q);
            q = (char)time & 0x000000FF;
            put_char(q);
        }

        else if (asc == 1)
        {
            put_char(9);
            rprintf("%d",time);
            put_char(9);
        }

        if ((RAMSPOT & 0x00000003) != 0)
        {
            //set/reset for mag sensors=======================================================
            IOCLR1 = 0x00020000;
            for (j = 0; j < 15; j++);
            IOSET1 = 0x00020000;
                
            //Get magx========================================================================
            if (magx_on == 1)
            {
                AD0CR = 0x0020FF10;	//AD0.4, P0.25
                AD0CR |= 0x01000000;	//start conversion
                
                while ((temp & 0x80000000) == 0)
                {
                        temp = AD0DR;
                }
                
                temp &= 0x0000FFC0;
                magx = temp / 0x00000040;
                
                AD0CR = 0x00000000;
                
                if (asc == 0)
                {
                    a = ((short)magx & 0xFF00) / 0x00000100;
                    q = (char)a;
                    put_char(q);
                    q = (char)magx & 0xFF;
                    put_char(q);
                }
        
                else if (asc == 1)
                {
                    rprintf("%d",magx);
                    put_char(9);
                }
            
                temp = 0;
            }

        }
    
        //Get magy=======================================================================
        if (magy_on == 1)
        {
            AD0CR = 0x0020FF20;	//AD0.5, P0.26
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
        
            temp &= 0x0000FFC0;
            magy = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)magy & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)magy & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",magy);
                put_char(9);
            }
        
            temp = 0;
        }
		
		
		//Get magz=======================================================================
        if (magz_on == 1)
        {
            AD0CR = 0x0020FF01;	//AD0.0, P0.27
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
        
            temp &= 0x0000FFC0;
            magz = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)magz & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)magz & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",magz);
                put_char(9);
            }
        
            temp = 0;
        }
		
    
        //Get accx=======================================================================
        if (accx_on == 1)
        {
            AD0CR = 0x0020FF02;	//AD0.1, P0.28
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
        
            temp &= 0x0000FFC0;
            accx = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)accx & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)accx & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",accx);
                put_char(9);
            }
            
            temp = 0;
        }
    
        //Get accy=======================================================================
        if (accy_on == 1)
        {
            AD0CR = 0x0020FF04;	//AD0.2
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
        
            temp &= 0x0000FFC0;
            accy = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)accy & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)accy & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",accy);
                put_char(9);
            }
            
            temp = 0;
        }
    
        //Get accz=======================================================================
        if (accz_on == 1)
        {
            AD0CR = 0x0020FF08;	//AD0.3
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
        
            temp &= 0x0000FFC0;
            accz = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)accz & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)accz & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",accz);
                put_char(9);
            }
            
            temp = 0;
        }
    
        
        
        //Get pitch=======================================================================
        if (pitch_on == 1)
        {
            AD1CR = 0x0020FF08;	//AD1.3, P0.12
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
        
            temp &= 0x0000FFC0;
            pitch = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)pitch & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)pitch & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",pitch);
                put_char(9);
            }
            
            temp = 0;
        }


        //Get roll=======================================================================
        if (roll_on == 1)
        {
            AD1CR = 0x0020FF10;	//AD1.4, P0.13
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
        
            temp &= 0x0000FFC0;
            roll = temp / 0x00000040;
    
            AD1CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)roll & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)roll & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",roll);
                put_char(9);
            }
            
            temp = 0;
        }
        
        //Get yaw=======================================================================
        if (yaw_on == 1)
        {
            AD1CR = 0x0020FF20;	//AD1.5, P0.15
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
        
            temp &= 0x0000FFC0;
            yaw = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 0)
            {
                a = ((short)yaw & 0xFF00) / 0x00000100;
                q = (char)a;
                put_char(q);
                q = (char)yaw & 0xFF;
                put_char(q);
            }
    
            else if (asc == 1)
            {
                rprintf("%d",yaw);
                put_char(9);
            }
        
            temp = 0;
        }
        

        //Stop Character Z
        put_char('Z');

        if (asc == 1)
        {
            put_char(10);
            put_char(13);
        }
        
        //Increment the counter
        time++;
        if (time >= 0x8000) time = 0;

        if (time % 64 == 0)
        {
            j = IOPIN0;
			k = IOPIN1;

            if ((k & 0x00080000) != 0x00080000)
            {
                stat2_off();
                stat0_on();
            }

            else if ((j & 0x00200000) != 0x00200000)
            {
                stat0_off();
                stat1_on();
            }
			
			else if ((j & 0x00400000) != 0x00400000)
            {
                stat1_off();
                stat2_on();
            }
            
        }


		if ((T0IR & 0x01) == 1)
		{
			rprintf("\r\n\nToo much data.  Please lower your sample frequency\r\n\n",0);
			return;
		}
		
        while ((T0IR & 0x01) == 0);   //Wait for timer to run out
        T0IR = 0x01;                  //reset timer int
        T0TCR = 3;  //reset timer
        T0TCR = 1;
        
        
        if (port == 1) temp3 = U1LSR;
        else temp3 = U0LSR;
        if ((temp3 & 0x01) != 0)	//if something comes in on port0...
        {
              if (port == 1) q = U1RBR;	//gotta read the RX buffer to set the flag back to 0
              else q = U0RBR;
              
              if (q == 32)
               {
                  stat1_off();
                  stat0_off();
                  return;
              }

              
        }
    }
}


void save_settings(void)
{

    iap_entry = (IAP)IAP_LOCATION;

    
    //Erase first ============================================================================================
    //prep...
    command[0] = 50;
    command[1] = 0x1A;
    command[2] = 0x1A;
    command[3] = 13;
    command[4] = 10;

    iap_entry(command, result);
    
    //erase...
    command[0] = 52;
    command[1] = 0x1A;
    command[2] = 0x1A;
    command[3] = 58982;
    command[4] = 0;
    
    iap_entry(command, result);


    //Then Write ============================================================================================
    //prep...
    command[0] = 50;
    command[1] = 0x1A;
    command[2] = 0x1A;
    command[3] = 13;
    command[4] = 10;

    iap_entry(command, result);


    //write...
    command[0] = 51;
    command[1] = 0x0007C000;
    command[2] = 0x40007E80;
    command[3] = 256;
    command[4] = 58982;
    
    iap_entry(command, result);

}


void set_flags(void)
{
    //Set active channels ============================================================================
    if ((RAMSPOT & 0x00000001) == 1) magx_on = 1;
    else magx_on = 0;

    if ((RAMSPOT & 0x00000002) == 2) magy_on = 1;
    else magy_on = 0;
	
	if ((RAMSPOT & 0x01000000) == 0x01000000) magz_on = 1;
    else magz_on = 0;

    if ((RAMSPOT & 0x00000004) == 4) accx_on = 1;
    else accx_on = 0;

    if ((RAMSPOT & 0x00000008) == 8) accy_on = 1;
    else accy_on = 0;

    if ((RAMSPOT & 0x00000010) == 0x10) accz_on = 1;
    else accz_on = 0;

    if ((RAMSPOT & 0x00000020) == 0x20) pitch_on = 1;
    else pitch_on = 0;

    if ((RAMSPOT & 0x00000040) == 0x40) roll_on = 1;
    else roll_on = 0;

    if ((RAMSPOT & 0x00000080) == 0x80) yaw_on = 1;
    else yaw_on = 0;

    //ASCII mode and auto run ===========================================================================
    if ((RAMSPOT & 0x00000100) == 0x100) asc = 1;
    else asc = 0;

    if ((RAMSPOT & 0x00000200) == 0x200) auto_run = 1;
    else auto_run = 0;

    //Accelerometer range ============================================================================
    if ((RAMSPOT & 0x00000C00) == 0)
	{
		IOCLR0 = 0x80000000;    //set for 1.5g sensitivity
		IOCLR1 = 0x00010000;
	}
	
    else if ((RAMSPOT & 0x00000C00) == 0x400)
    {
        IOSET1 = 0x00010000;    // 
        IOCLR0 = 0x80000000;    //set for 2g sensitivity
    }

    else if ((RAMSPOT & 0x00000C00) == 0x800)
    {
        IOSET0 = 0x80000000;    // 
        IOCLR1 = 0x00010000;    //set for 4g sensitivity
    }

    else if ((RAMSPOT & 0x00000C00) == 0xC00)
    {
        IOSET0 = 0x80000000;    //set for 6g
		IOSET1 = 0x00010000;
    }

    //Set Frequency =======================================================================================
    freq = (RAMSPOT & 0x007FF000)/0x1000;
    T0MR0 = 58982400 / freq;

    //Set output port======================================================================================
    if ((RAMSPOT & 0x00800000) == 0x800000) BT_active = 1;

    else BT_active = 0;
}


