static void
UART0ISR(void)
{
      char temp;
      int j;
      
      RX_array[RX_in] = U0RBR;
      RX_in++;

      if (RX_in >= 128) RX_in = 0;
      
      temp = U0IIR;	//have to read this to clear the int

      /* Update VIC priorities */
      VICVectAddr = 0;
      
}
