#include <iostream>

#include "MotorEncoders.h"

using namespace std;

int main(void) {
	MotorEncoders encoders;

	while(true) {
		cout << "Heading = " << encoders.getHeading() << endl;
		usleep(100000);
	}
}
