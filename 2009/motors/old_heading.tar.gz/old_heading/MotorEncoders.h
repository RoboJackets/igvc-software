// TODO: find which of these can be removed/moved to .cc file
#include <stdio.h>    /* Standard input/output definitions */
#include <stdlib.h>

#include <stdint.h>   /* Standard types */
#include <string.h>   /* String function definitions */
#include <unistd.h>   /* UNIX standard function definitions */
#include <fcntl.h>    /* File control definitions */
#include <termios.h>  /* POSIX terminal control definitions */
#include <sys/ioctl.h>
#include <getopt.h>
#include <stdbool.h>

typedef struct {
	float heading;
} arduino_reply_t;

enum arduino_var_t {
	HEADING = 0
};

class MotorEncoders {
	public:
		/* Constructor */
		MotorEncoders(void);

		/* Gets the current global heading in radians */
		double getHeading(void);

		/**/
		bool setHeading(double heading);

	private:

		bool readFully(int fd, void* buf, size_t numBytes);
		bool writeFully(int fd, void* buf, size_t numBytes);
		int serialportInit(const char* serialport, speed_t baud);

		/* Serial port file descriptor */
		int arduinoFD;

		void closeArduinoConnection(void);
		bool getArduinoStatus(arduino_reply_t *status);
		bool setArduinoVar(arduino_var_t var, char value);
		bool serialFlush(int fd);
};

