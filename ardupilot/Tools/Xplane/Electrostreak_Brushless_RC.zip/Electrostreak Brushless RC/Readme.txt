This model is based directly on my Great Planes Electrostreak ARF kit, modified as follows:

 - Replacement of stock power plant with E-Flite Power 32 Outrunner Brushless motor,
   capable of supporting up to 14v and 45A continuous, with 600W rated power, weight 7.3 oz.
   770 KV, meaning 7700 RPM at 10V.  

 - Speed control:  Castle Creations Phoenix 45, 45A continuous, 60A burst.  

 - Prop:  Graupner Gear prop 12x10 inch folding prop.  This is a substantial up-size from the
   stock 8x5 folder.  (Note, prop size units are in inches, diameter x pitch.  The Pitch is standard, 
   and means how many units of air are moved through the prop for every revolution.  Naturally this
   is not available as an input method in x-plane, but multiplying pitch by revs per hour and converting
   into mph seems to be a start)

 - Battery:  A single Thunder Power Prolite 3S (11.1v nominal), 2100 mah, 15C continuous, 20C burst 
   (31.5/42A) discharge rate Li-poly pack satisfies the 34A max static current drain for my setup. ]
   The power consumption is around 350W, about 1/2 hp.  

 - Flaperons:  Instead of a single servo controlling both ailerons, I installed 2, one for each
   side of the wing.  So, there are flaps available through the mixing controls.

I used a ruler and converted my plane into electronic form.  Paint is just pictures of my 
2nd Electrostreak, though I have not included the 3 wires sticking out of the right front
fuselage from the motor, then back inside to the speed controller.  The motor used all the 
available space in the fuse, and I had to cut the fiberglass to route the wiring for the 
huge motor.  It did make the weight balance nicely compared with my first Electrostreak, 
which required 3 oz of lead in the nose to help balance the smaller, 4.7 oz himax 3516-1130
outrunner driving a 9x6 prop.  The one downside to the giant prop is that the aircraft becomes
ridiculously difficult to hear in certain conditions.  It seems very efficient.

X-plane cannot model folding props.  The real RC aircraft is best suited for folding props, 
especially since it has no landing gear.  Also, it really sounds like a little jet when it 
makes a high speed pass over one's head with the prop stowed.  I wish the functionality existed,
but even going to a variable pitched prop with feather doesn't seem to give the right lack of drag.
Naturally, the thrust vectoring method of stowing props does not work either.  

So, this plane has a fixed prop and landing gear.  Be sure to release the brakes before hitting
the throttle, and raise the gear after takeoff -- they aren't supposed to be there.  You should 
have plenty of power at 50% throttle, just like the real thing.  100% throttle provides a silly
amount of power.

This is not a trainer, and does not have nice self-recovery characteristics.  Be sure to adjust 
the trims to your liking and marvel in the high-speed, ultra-high performance of this fantastic
airplane.  I understand that it's a bit of an on-the-wing-only airplane with stock power, but
not with a modern powerplant.  I think everyone should have an Electrostreak to fly, so here's
my implementation of a high-power, 100 mph version.

Rolf Karlstad